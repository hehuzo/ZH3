﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using zh3_hehuzo_forms.Models;

namespace zh3_hehuzo_forms
{
    public partial class Form2 : Form
    {
        SeCocktailsContext context = new SeCocktailsContext();

        public Form2()
        {
            InitializeComponent();
        }
        private void SelectRecipe()
        {
            var selectedcocktail = (Cocktail)listBoxCocktail.SelectedItem;

            var selected = from x in context.Recipes
                           where x.CocktailFk == selectedcocktail.CocktailSk
                           select new DetailedRecipeItem
                           {
                               RecipeSk = x.RecipeSk,
                               MaterialName = x.MaterialFkNavigation.Name,
                               MaterialType = x.MaterialFkNavigation.TypeFkNavigation.Name,
                               Quantity = x.Quantity,
                               UnitName = x.MaterialFkNavigation.UnitFkNavigation.Name,
                           };

            detailedRecipeItemBindingSource.DataSource = selected.ToList();
        }
        private void MaterialFilter()
        {
            var material = from x in context.Materials
                           where x.Name.Contains(textBoxMaterial.Text)
                           select x;
            listBoxMaterial.DataSource = material.ToList();
            listBoxMaterial.DisplayMember = "Name";
        }
        private void CocktailFilter()
        {
            var cocktail = from x in context.Cocktails
                           where x.Name.Contains(textBoxCocktail.Text)
                           select x;
            listBoxCocktail.DataSource = cocktail.ToList();
            listBoxCocktail.DisplayMember = "Name";
        }
        private void button2_Click(object sender, EventArgs e)
        {
            //törlés
            var delete = ((DetailedRecipeItem)detailedRecipeItemBindingSource.Current).RecipeSk;
            var todelete = (from x in context.Recipes
                            where x.RecipeSk == delete
                            select x).FirstOrDefault();
            context.Recipes.Remove(todelete);

            try
            {
                context.SaveChanges();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }

            SelectRecipe();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //hozzáadás
            var cocktailId = ((Cocktail)listBoxCocktail.SelectedItem).CocktailSk;
            var materialId = ((Material)listBoxMaterial.SelectedItem).MaterialId;
            var quan = textBox3.Text;
            Recipe recipe = new Recipe();
            recipe.CocktailFk = cocktailId;
            recipe.MaterialFk = materialId;
            recipe.Quantity = Convert.ToInt64(quan);

            context.Recipes.Add(recipe);
            try
            {
                context.SaveChanges();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            SelectRecipe();
        }

        private void listBoxCocktail_SelectedIndexChanged(object sender, EventArgs e)
        {
            SelectRecipe();
        }

        private void textBoxMaterial_TextChanged(object sender, EventArgs e)
        {
            MaterialFilter();
        }

        private void textBoxCocktail_TextChanged(object sender, EventArgs e)
        {
            CocktailFilter();
        }

        private void listBoxMaterial_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            CocktailFilter();
            MaterialFilter();
        }
    }
    public class DetailedRecipeItem
    {
        public int RecipeSk { get; set; }
        public string MaterialName { get; set; }
        public string MaterialType { get; set; }
        public decimal Quantity { get; set; }
        public string UnitName { get; set; }
    }
}
